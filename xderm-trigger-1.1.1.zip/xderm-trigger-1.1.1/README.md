## Requirement
- xderm-gui/xderm-mini

## How to use?
- Download .ipk on [release](https://github.com/Kry9toN/xderm-trigger/releases)

- Install with CLI
```
opkg install xderm-trigger*.ipk
```
- Then reboot

- Enjoy

## For development

How to build??

- First you must on xderm-trigger folder

- Make only binary
```
make
```

- Make ipk installer
```
make ipk
```
